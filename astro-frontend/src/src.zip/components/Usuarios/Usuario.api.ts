export async function createUsuario(newUsuario: any){

    const response = await fetch('http://localhost:3000/api/v1/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newUsuario)
    })

    const data = await response.json();

    console.log(data);
}

export async function getUsuarios(dpi: string){ 
    const data = await fetch(`http://localhost:3000/api/v1/usuario/${dpi}`);
    return await data.json();

}

export async function updateUsuario(){
    
}