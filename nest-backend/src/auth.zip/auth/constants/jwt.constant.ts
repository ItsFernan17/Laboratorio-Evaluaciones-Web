
export const jwtConstants = {
    secret: '706ca6272bfd7ad95b5244d09256c5c46324dbae76bf0791bf90c26f478f070c',
};