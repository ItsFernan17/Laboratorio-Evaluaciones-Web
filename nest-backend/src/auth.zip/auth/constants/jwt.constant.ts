
export const jwtConstants = {
    secret: 'grupo1desarrolloweb',
};